let unidad19 = setInterval(() => {
  if (window.location.href.indexOf("https://prod.progrentis.com/") !== -1) {
    document.querySelector("#view-panel > div.upper-section > div.info-user > div.advance-section > div > div.unidad").innerHTML = "UNIDAD 19";
    document.querySelector("#view-panel > div.upper-section > div.info-user > div.user-section > div.flip-card.flip-to-front > div.avatar-flip.front-card > div.points > span.big").innerHTML = "1786";
  }
}, 100);

console.log("Ya jalo lo de la unidad");

setInterval(() => {
  if (window.location.href.indexOf("https://prod.progrentis.com/plat/elite/panel.aspx#/panel/historial") !== -1) {
    const updateElement = (index, pts) => {
      const selector = `#historial-resumen > div.workspace > div:nth-child(${index}) > div.progress > div`;
      const element = document.querySelector(selector);
      if (element) {
        element.style.backgroundColor = "#00d3ae";
        element.style.width = "100%";
        element.innerHTML = `${pts} pts.`;
      }
    };

    updateElement(10, 90);
    updateElement(11, 87);
    updateElement(12, 92);
    updateElement(13, 86);
    updateElement(14, 96);
    updateElement(15, 95);
    updateElement(16, 90);
    updateElement(17, 91);
    updateElement(18, 98);
    updateElement(19, 89);
  }
}, 100);
